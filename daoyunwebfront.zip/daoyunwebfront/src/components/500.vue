<template>
  <div>
    <img src="../assets/img/500.jpg" alt="500.jpg">
  </div>
</template>

<script>
export default {
    name: "500"
};
</script>

<style>
</style>
