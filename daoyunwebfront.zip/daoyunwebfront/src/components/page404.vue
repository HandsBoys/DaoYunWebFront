<template>
  <div>
    <img src="../assets/img/404.jpg" alt="404.jpg">
  </div>
</template>

<script>
export default {
    name: "page404"
};
</script>

<style>
</style>
