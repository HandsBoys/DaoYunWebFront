<template>
  <div>
    <img src="../assets/img/403.jpg" alt="403.jpg">
  </div>
</template>

<script>
export default {
    name: "page403"
};
</script>

<style>
</style>
