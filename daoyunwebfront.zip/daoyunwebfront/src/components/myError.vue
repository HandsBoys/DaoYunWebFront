<template>
  <div>
    <img src="../assets/img/myError.jpg" alt="myError.jpg">
  </div>
</template>

<script>
export default {
    name: "myError"
};
</script>

<style>
</style>
